file=open('example.txt','a')
#write in Append mode 
file.write('/n this new line data is written by the append method in file handling')
file.close()
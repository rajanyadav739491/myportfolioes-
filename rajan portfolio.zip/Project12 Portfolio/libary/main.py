# import mylib
# from mylib import packege1
# from mylib.packege1 import module1
# from mylib.packege1.module1 import show
# print(show()) 


# import mylib
# from mylib import packege2
# from mylib.packege2 import module3
# from mylib.packege2.module3 import show
# print(show()) 


# import mylib
# from mylib import packege3
# from mylib.packege3 import module4
# from mylib.packege3.module4 import show
# print(show()) 

   
file=open('todo.txt','a')
#write tasks to the file
file.read('/n this new line data is read by the append method in file handling')
file.close()
 


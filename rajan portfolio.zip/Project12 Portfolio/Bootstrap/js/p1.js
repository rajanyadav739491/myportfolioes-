document.write("Welcome To Techpile");
color:red;